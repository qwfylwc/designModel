package com.study.model.createType.factory;

public class BMWFactory320 implements BMWFactory{

	@Override
	public BMW createBMW() {
		return new BMW320();
	}

}
