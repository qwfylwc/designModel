package com.study.model.createType.singleton;

/**  
 * 饿汉式,线程安全 但效率比较低
 */  
public class SingletonHungry {
	/* 持有私有静态实例，防止被引用，被串改 */  
    private static final SingletonHungry instance = new SingletonHungry(); 
    
    /* 私有构造方法，防止被实例化 */  
    private SingletonHungry() {  
    } 
    
    /* 静态工程方法，创建实例 */  
    public static SingletonHungry getInstance() {
        return instance;  
    }
}
