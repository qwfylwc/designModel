package com.study.model.createType.factory.abstractfactory;

//越野车
public class SuvCarBMW extends SuvCar{
	
	@Override
	public String createCarType() {
		return "宝马越野车";
	}
}
