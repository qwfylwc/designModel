package com.study.model.createType.factory.abstractfactory;

public class CarFactoryBenz implements CarFactory{

	@Override
	public SaloonCar makeSaloonCar() {
		return new SaloonCarBenz();
	}

	@Override
	public SuvCar makeSuvCar() {
		return new SuvCarBenz();
	}
}
