package com.study.model.createType.singleton;

import java.io.Serializable;

/**  
 * 可序列化的饿汉式,线程安全  ,反序列化时导致单例破坏
 */  
public class SingletonHungrySeriable implements Serializable{

	private static final long serialVersionUID = 1L;
	/* 持有私有静态实例，防止被引用，被串改 */  
    private static final SingletonHungrySeriable instance = new SingletonHungrySeriable(); 
    
    /* 私有构造方法，防止被实例化 */  
    private SingletonHungrySeriable() {  
    } 
    
    /* 静态工程方法，创建实例 */  
    public static SingletonHungrySeriable getInstance() {
        return instance;  
    }
    
    //反序列化时导致单例破坏,通过jdk反序列化机制，实现readResolve方法
    private  Object readResolve(){
        return  instance;
    }
}
