package com.study.model.createType.factory;


public class BMW320 extends BMW {

	@Override
	public String createCarType() {
		return "BMW320";
	}
    
	@Override
	public String createColor() {
		return "red";
	}

	@Override
	public int[] createSize() {
		return new int[]{2400,1600,1400};
	}
}
