package com.study.model.createType.factory;

public class BMW523 extends BMW {

	@Override
	public String createCarType() {
		return "BMW523";
	}

	@Override
	public String createColor() {
		return "blue";
	}

	@Override
	public int[] createSize() {
		return new int[]{2600,1800,1780};
	} 
}
