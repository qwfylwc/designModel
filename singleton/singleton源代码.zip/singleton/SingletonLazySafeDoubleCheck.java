package com.study.model.createType.singleton;

/**  
 * 懒汉式,线程安全  对 SingletonLazySafe 进行优化
 */  
public class SingletonLazySafeDoubleCheck {
	/* 持有私有静态实例，防止被引用，此处赋值为null，目的是实现延迟加载 */  
    private static SingletonLazySafeDoubleCheck instance = null; 
    
    /* 私有构造方法，防止被实例化 */  
    private SingletonLazySafeDoubleCheck() {
    } 
    
    /* 静态工程方法，创建实例  使用synchronized 避免多线程访问时，可能造成重的复初始化问题 */  
    public static SingletonLazySafeDoubleCheck getInstance() {  
        if (instance == null) {  
        	//同步代码块（对象未初始化时，使用同步代码块，保证多线程访问时对象在第一次创建后，不再重复被创建）
            synchronized (SingletonLazySafeDoubleCheck.class) {
                //未初始化，则初始instance变量
                if (instance == null) {
                    instance = new SingletonLazySafeDoubleCheck();   
                }
            }
        }
        return instance;  
    }
}
