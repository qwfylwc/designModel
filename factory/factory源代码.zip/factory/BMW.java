package com.study.model.createType.factory;

public abstract class BMW {

    /**
     * 设置车型号
     */
    public abstract String createCarType();
	
    /**
     * 设置车颜色
     */
    public abstract String createColor();
    
    /**
     * 设置车尺寸  [长 ,宽, 高]
     * @return
     */
    public abstract int[] createSize();
    
    public void printInfo(){
    	System.out.println("制造-->"+createCarType());
    	System.out.println("颜色-->"+createColor());
    	int[] size = createSize();
    	System.out.println("尺寸-->长:"+size[0]+" 宽:"+size[1]+" 高:"+size[2]);
    	System.out.println();
    }
}
