package com.study.model.createType.factory.abstractfactory;

public interface CarFactory {

	public SaloonCar makeSaloonCar();
	public SuvCar makeSuvCar();
}
