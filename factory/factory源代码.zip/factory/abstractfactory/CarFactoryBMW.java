package com.study.model.createType.factory.abstractfactory;

public class CarFactoryBMW implements CarFactory{

	@Override
	public SaloonCar makeSaloonCar() {
		return new SaloonCarBMW();
	}

	@Override
	public SuvCar makeSuvCar() {
		return new SuvCarBMW();
	}

	
}
