package com.study.model.createType.factory;

public interface  BMWFactory {

	public BMW createBMW();
}
