package com.study.model.createType.factory.abstractfactory;

public class SaloonCarBenz extends SaloonCar{

	@Override
	public String createCarType() {
		return "奔驰轿车";
	}
}
