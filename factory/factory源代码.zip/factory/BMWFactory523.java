package com.study.model.createType.factory;

public class BMWFactory523 implements BMWFactory{

	@Override
	public BMW createBMW() {
		return new BMW523();
	}

}
