package com.study.model.createType.factory.abstractfactory;

public class SaloonCarBMW extends SaloonCar{

	@Override
	public String createCarType() {
		return "宝马轿车";
	}
}
