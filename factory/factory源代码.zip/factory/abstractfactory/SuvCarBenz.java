package com.study.model.createType.factory.abstractfactory;

//越野车
public class SuvCarBenz extends SuvCar{
	@Override
	public String createCarType() {
		return "奔驰越野车";
	}
}
