package com.study.model.createType.factory;

public class BMW800 extends BMW {

	@Override
	public String createCarType() {
		return "BMW800";
	}

	@Override
	public String createColor() {
		return "write";
	}

	@Override
	public int[] createSize() {
		return new int[]{2780,1860,1980};
	} 
}
