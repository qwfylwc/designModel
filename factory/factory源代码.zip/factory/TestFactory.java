package com.study.model.createType.factory;


import org.junit.Test;

public class TestFactory{
	
	@Test
	public void testSimpleFactory(){
		System.out.println("测试简单工厂......");
		SimpleFactory factory = new SimpleFactory();  
        BMW bmw320 = factory.createBMW(320); 
        bmw320.printInfo();
        BMW bmw523 = factory.createBMW(523);
        bmw523.printInfo();
	}
	
	@Test
	public void testStaticFactory(){
		System.out.println("测试静态工厂......");
        BMW bmw320 = StaticFactory.createBMW(320); 
        bmw320.printInfo();
        
        BMW bmw523 = StaticFactory.createBMW(523);
        bmw523.printInfo();
	}
	
	@Test
	public void testFactoryMothed(){
		
		
		System.out.println("测试工厂方法......");
        BMW bmw320 = new BMWFactory320().createBMW();
        bmw320.printInfo();
        
        BMW bmw523 = new BMWFactory523().createBMW();
        bmw523.printInfo();
        
        //增加新的车型  800 只需要新建BMW800和BMW800Factory
        BMW bmw800 = new BMWFactory800().createBMW();
        bmw800.printInfo();
	}
}
