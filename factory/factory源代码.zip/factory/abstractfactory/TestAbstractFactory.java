package com.study.model.createType.factory.abstractfactory;


import org.junit.Test;

public class TestAbstractFactory{
	
	@Test
	public void testAbstractFactory(){
		
		//需要订购奔驰厂家的轿车和越野车
		CarFactory carFactory = new CarFactoryBenz();
		
		//生产奔驰轿车
		carFactory.makeSaloonCar().printInfo();
		
		//生产奔驰越野车
		carFactory.makeSuvCar().printInfo();
	}
}
