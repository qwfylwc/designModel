package com.study.model.createType.factory.abstractfactory;

//越野车
public abstract class SuvCar extends Car{

}
