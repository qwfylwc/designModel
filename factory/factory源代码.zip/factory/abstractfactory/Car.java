package com.study.model.createType.factory.abstractfactory;

public abstract class Car {
	
    /**
     * 设置车型号
     */
    public abstract String createCarType();
	
    
    public void printInfo(){
    	System.out.println("车型制造-->"+createCarType());
    	System.out.println();
    }
}
