package com.study.model.createType.factory.abstractfactory;

//轿车
public abstract class SaloonCar extends Car{

}
