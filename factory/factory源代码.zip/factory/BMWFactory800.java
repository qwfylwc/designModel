package com.study.model.createType.factory;

public class BMWFactory800 implements BMWFactory{

	@Override
	public BMW createBMW() {
		return new BMW800();
	}

}
